# Khaby Lame Website - projet Twitch

Projet en cours de dev live sur Twitch (janvier 2023) : on recode un site trouvé sur la page des Awwwards, un one-page en scrolling vertical plein d'effets discrets mais efficaces. Enjoy !


https://user-images.githubusercontent.com/26569119/214188690-d16da44a-3b26-49cf-81f8-aefc33146007.mp4


- Le site d'origine : ✨ https://khaby.iconmagazine.de/ ✨
- Ce repo est public, n'hésite pas à PR, cloner...
- Pour me retrouver sur Twitch : https://www.twitch.tv/console_buche
- Twitter : https://twitter.com/Console_buche
- Youtube : https://www.youtube.com/channel/UCxD5q70zyfmBBp_WcqVUuhA

## LA STACK

React / Three.js (R3F)

## LANCER LE PROJET

Clone le repo, puis

```sh
yarn
yarn dev
```
