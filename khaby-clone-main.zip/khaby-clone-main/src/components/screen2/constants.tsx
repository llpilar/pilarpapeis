export const SCREEN2_OFFSET_START_Y = -11;
