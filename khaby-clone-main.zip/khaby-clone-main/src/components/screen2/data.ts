export const dataScreen2 = ["N°1", "Tiktoker", "Actor", "Icon", "Italian"];
