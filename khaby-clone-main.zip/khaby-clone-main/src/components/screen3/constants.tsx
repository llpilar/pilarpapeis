export const SCREEN3_OFFSET_START_Y = -13.5;
export const PHOTO_OFFSET_FACTOR = 0.5;
